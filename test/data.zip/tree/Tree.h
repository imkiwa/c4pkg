#pragma once

#include <errno.h>
#include <stdbool.h>

#define CAPACITY_INFINITY -1

typedef void(*value_deleter_t)(void*);

struct node;
struct tree;

struct tree
{
  int capacity;
  int count;
  struct node *root;
};

struct node
{
  int hash;
  int keysz;
  
  char *key;
  void *value;
  
  value_deleter_t deleter;
  
  struct node *parent;
  struct node *left;
  struct node *right;
};


/**
 * Create a tree
 *
 * return NULL and set errno if something wrong
 */
struct tree* tree_new(int capacity);

/**
 * Delete a tree
 */
void tree_delete(struct tree *tree);

/**
 * Create a new node and insert it into the tree
 * if the node already exists, it will only set the value of the node
 *
 * return true everything goes well
 */
bool tree_insert_node(struct tree *tree, char *key, void *value);

/**
 * Remove a node and its children based on a given key
 *
 * return true if the node is removed
 */
bool tree_remove_node(struct tree *tree, char *key);

/**
 * Lookup a node based on a given key
 *
 * return NULL if the node is not found
 */
struct node* tree_find(struct tree *tree, char *key);


struct node* node_new(const char *key, void *value);
void node_delete(struct node *node);
void node_set(struct node *node, void *value);
int node_hash(struct node *node);
