#include <stdio.h>

int main(int argc, char **argv)
{
  printf("%d\n", snprintf(NULL, 0, "hHhhhh%d%xh", 64, main));
}
